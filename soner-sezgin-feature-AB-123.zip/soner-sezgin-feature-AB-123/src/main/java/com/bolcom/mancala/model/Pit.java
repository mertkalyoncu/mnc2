package com.bolcom.mancala.model;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class Pit implements Serializable {
    int id;
    int stoneCount;
    Player owner;
    PitType type;

    public void addStone(int count) {
        stoneCount += count;
    }

    public int removeAllStones() {
        int stoneCountToBeRemoved = stoneCount;
        stoneCount = 0;
        return stoneCountToBeRemoved;
    }
}