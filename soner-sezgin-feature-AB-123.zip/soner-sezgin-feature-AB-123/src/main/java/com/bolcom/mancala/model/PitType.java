package com.bolcom.mancala.model;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum PitType {
    SMALL(1), BIG(2);
    private final int id;
}
