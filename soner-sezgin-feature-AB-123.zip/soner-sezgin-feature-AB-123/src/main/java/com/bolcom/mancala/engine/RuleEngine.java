package com.bolcom.mancala.engine;

import com.bolcom.mancala.model.Node;
import lombok.experimental.UtilityClass;

import java.util.Arrays;

@UtilityClass
public class RuleEngine {

    public void apply(Board board, Node lastNode) {
        Arrays.stream(Rule.values())
                .forEach(r -> r.apply(board, lastNode));
    }
}
