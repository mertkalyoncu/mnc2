package com.bolcom.mancala.engine;

import com.bolcom.mancala.model.Node;
import com.bolcom.mancala.model.PitType;
import com.bolcom.mancala.model.Player;
import lombok.experimental.UtilityClass;

@UtilityClass
public class PlayEngine {

    /**
     * Sows the stones on to the right, one in each of the following pits.
     *
     * @param starterNode The node whose stones will be removed from.
     * @return The node which the last stone landed in.
     */
    public Node sow(Node starterNode) {
        int stoneCount = starterNode.getPit().removeAllStones();
        Player owner = starterNode.getPit().getOwner();
        Node node = starterNode;
        while (stoneCount > 0) {
            node = node.getNext();
            if (isOpponentBigPit(owner, node)) {
                continue;
            }
            node.getPit().addStone(1);
            stoneCount--;
        }
        return node;
    }

    private boolean isOpponentBigPit(Player owner, Node node) {
        return owner.other() == node.getPit().getOwner() && node.getPit().getType() == PitType.BIG;
    }
}
