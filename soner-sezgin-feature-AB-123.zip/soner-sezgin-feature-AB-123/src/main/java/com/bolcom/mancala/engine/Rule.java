package com.bolcom.mancala.engine;

import com.bolcom.mancala.model.Node;
import com.bolcom.mancala.model.PitType;

public enum Rule {
    TAKE_OPPONENT_STONES {
        @Override
        void apply(Board board, Node lastNode) {
            if (lastNode.getPit().getOwner() == board.getTurn()
                    && lastNode.getPit().getStoneCount() == 1
                    && lastNode.getPit().getType() == PitType.SMALL) {
                int removedStoneCount = lastNode.getOppositeNode().getPit().removeAllStones();
                removedStoneCount += lastNode.getPit().removeAllStones();
                board.getBigPitNode(board.getTurn()).getPit().addStone(removedStoneCount);
            }
        }
    },
    EXTRA_TURN {
        @Override
        void apply(Board board, Node lastNode) {
            if (lastNode.getPit().getType() != PitType.BIG) {
                board.switchTurn();
            }
        }
    };

    abstract void apply(Board board, Node lastNode);
}
