package com.bolcom.mancala.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode(of = "pit")
@RequiredArgsConstructor
public class Node implements Serializable {
    private final Pit pit;
    private Node next;

    public Node getOppositeNode() {
        Node node = this;
        int oppositePitId = getOppositePitId(this.pit.getId());
        Player owner = this.pit.getOwner();
        do {
            Pit pit = node.getPit();
            if (owner == pit.getOwner().other() && pit.getId() == oppositePitId) {
                return node;
            }
            node = node.getNext();
        } while (!node.equals(this));

        //cannot happen
        throw new AssertionError();
    }

    private int getOppositePitId(int pitId) {
        return 7 - pitId;
    }
}
