package com.bolcom.mancala.engine;

import com.bolcom.mancala.model.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.bolcom.mancala.Constants.*;

@Getter
@EqualsAndHashCode
public class Board implements Serializable {
    private Node head;
    private Node tail;
    private Player turn;

    private Board() {
        this.turn = Player.PLAYER_1;
    }

    /**
     * Initializes a board to start the game.
     *
     * @return {@link Board}
     */
    public static Board createInitialBoard() {
        return new Board()
                .addNode(createSmallPit(1, Player.PLAYER_1))
                .addNode(createSmallPit(2, Player.PLAYER_1))
                .addNode(createSmallPit(3, Player.PLAYER_1))
                .addNode(createSmallPit(4, Player.PLAYER_1))
                .addNode(createSmallPit(5, Player.PLAYER_1))
                .addNode(createSmallPit(6, Player.PLAYER_1))
                .addNode(createBigPit(Player.PLAYER_1))
                .addNode(createSmallPit(1, Player.PLAYER_2))
                .addNode(createSmallPit(2, Player.PLAYER_2))
                .addNode(createSmallPit(3, Player.PLAYER_2))
                .addNode(createSmallPit(4, Player.PLAYER_2))
                .addNode(createSmallPit(5, Player.PLAYER_2))
                .addNode(createSmallPit(6, Player.PLAYER_2))
                .addNode(createBigPit(Player.PLAYER_2));
    }

    private static Pit createBigPit(Player player) {
        return Pit.builder()
                .id(BIG_PIT_ID)
                .type(PitType.BIG)
                .owner(player)
                .stoneCount(INITIAL_BIG_PIT_STONE_COUNT)
                .build();
    }

    private static Pit createSmallPit(int id, Player player) {
        return Pit.builder()
                .id(id)
                .type(PitType.SMALL)
                .owner(player)
                .stoneCount(INITIAL_SMALL_PIT_STONE_COUNT)
                .build();
    }

    private Board addNode(Pit pit) {
        Node newNode = new Node(pit);
        if (head == null) {
            head = newNode;
        } else {
            tail.setNext(newNode);
        }
        tail = newNode;
        tail.setNext(head);
        return this;
    }

    /**
     * @return An ArrayList representation of the stones to be used on frontend.
     */
    public List<Integer> getStonesInOrder() {
        List<Integer> stones = new ArrayList<>();
        Node node = head;
        do {
            stones.add(node.getPit().getStoneCount());
            node = node.getNext();
        } while (!node.equals(head));
        return stones;
    }

    public Node getNode(Player player, int pitId) {
        Node node = head;
        do {
            if (node.getPit().getOwner() == player && node.getPit().getId() == pitId) {
                return node;
            }
            node = node.getNext();
        } while (!node.equals(head));

        //cannot happen
        throw new AssertionError(String.format("Unexpected error: Node cannot be found for player:%s and pitId:%s", player, pitId));
    }

    public Node getBigPitNode(Player player) {
        return getNode(player, BIG_PIT_ID);
    }

    /**
     * @return Converts Board to it's simpler representation to be used on frontend.
     */
    public BoardResponse getBoardResponse() {
        return BoardResponse.builder()
                .winner(calculateWinner())
                .stones(getStonesInOrder())
                .turn(turn)
                .build();
    }

    /**
     * @return The player who wins or null if there is no winner
     */
    private Player calculateWinner() {
        if (getSmallPitsTotalCount(Player.PLAYER_1) == 0 || getSmallPitsTotalCount(Player.PLAYER_2) == 0) {
            emptySmallPits();
            int player1TotalScore = getBigPitNode(Player.PLAYER_1).getPit().getStoneCount();
            int player2TotalScore = getBigPitNode(Player.PLAYER_2).getPit().getStoneCount();
            return player1TotalScore > player2TotalScore ? Player.PLAYER_1 : Player.PLAYER_2;
        }
        return null;
    }

    private void emptySmallPits() {
        Node node = head;
        do {
            if (node.getPit().getType() == PitType.SMALL) {
                int removedStones = node.getPit().removeAllStones();
                Player owner = node.getPit().getOwner();
                getBigPitNode(owner).getPit().addStone(removedStones);
            }
            node = node.getNext();
        } while (node != head);
    }

    private int getSmallPitsTotalCount(Player player) {
        int totalCount = 0;
        Node node = head;
        do {
            if (node.getPit().getOwner() == player && node.getPit().getType() == PitType.SMALL) {
                totalCount += node.getPit().getStoneCount();
            }
            node = node.getNext();
        } while (!node.equals(head));
        return totalCount;
    }

    public void setTurn(Player turn) {
        this.turn = turn;
    }

    public void switchTurn() {
        this.turn = turn.other();
    }
}
