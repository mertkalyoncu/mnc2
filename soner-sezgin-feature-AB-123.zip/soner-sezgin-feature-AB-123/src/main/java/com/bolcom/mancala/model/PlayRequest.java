package com.bolcom.mancala.model;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;

@Data
public class PlayRequest {
    @NotNull(message = "Player cannot be null")
    private Player player;
    @Range(min = 1, max = 6, message = "pitId must be at least 1 and at most 6")
    private int pitId;
}
