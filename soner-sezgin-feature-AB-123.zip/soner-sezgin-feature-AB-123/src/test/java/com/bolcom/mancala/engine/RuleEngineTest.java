package com.bolcom.mancala.engine;

import com.bolcom.mancala.model.Node;
import com.bolcom.mancala.model.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class RuleEngineTest {

    private static Board board;

    @BeforeEach
    void setUp() {
        board = Board.createInitialBoard();
        board.setTurn(Player.PLAYER_1);
        Node head = board.getHead();
        Node node = head;
        List<Integer> stones = List.of(1, 6, 1, 12, 2, 10, 2, 7, 1, 8, 7, 7, 7, 1);
        int i = 0;
        do {
            node.getPit().setStoneCount(stones.get(i++));
            node = node.getNext();
        } while (node != head);
    }

    @Test
    void apply_take_opponent_stones() {
        // given:
        int expectedOpponentRemainingStoneCount = 0;
        int expectedBigPitStoneCount = 10;
        Player expectedTurn = Player.PLAYER_2;
        Node lastNodeLanded = board.getNode(Player.PLAYER_1, 3);
        // when:
        RuleEngine.apply(board, lastNodeLanded);
        int actualOpponentRemainingStoneCount = lastNodeLanded.getOppositeNode().getPit().getStoneCount();
        int actualBigPitStoneCount = board.getBigPitNode(Player.PLAYER_1).getPit().getStoneCount();
        Player actualTurn = board.getTurn();
        // then:
        assertThat(actualTurn).isEqualTo(expectedTurn);
        assertThat(actualOpponentRemainingStoneCount).isEqualTo(expectedOpponentRemainingStoneCount);
        assertThat(actualBigPitStoneCount).isEqualTo(expectedBigPitStoneCount);
    }

    @Test
    void apply_extra_turn() {
        // given:
        Player expectedTurn = Player.PLAYER_1;
        // when:
        Node lastNodeLanded = board.getBigPitNode(Player.PLAYER_1);
        RuleEngine.apply(board, lastNodeLanded);
        Player actualTurn = board.getTurn();
        // then:
        assertThat(actualTurn).isEqualTo(expectedTurn);
    }

}