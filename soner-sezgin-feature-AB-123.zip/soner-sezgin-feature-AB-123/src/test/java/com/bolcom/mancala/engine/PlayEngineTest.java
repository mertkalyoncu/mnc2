package com.bolcom.mancala.engine;

import com.bolcom.mancala.model.BoardResponse;
import com.bolcom.mancala.model.Node;
import com.bolcom.mancala.model.Player;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class PlayEngineTest {

    private static Board board;

    @BeforeAll
    static void setUp() {
        board = Board.createInitialBoard();
    }

    @Test
    @Order(1)
    void sow_happy_path() {
        // given:
        Player player = Player.PLAYER_1;
        int pitId = 1;
        Node starterNode = board.getNode(player, pitId);
        List<Integer> lastStateStones = List.of(0, 7, 7, 7, 7, 7, 1, 6, 6, 6, 6, 6, 6, 0);
        int expectedLastNodeId = 7;
        // when:
        Node actualLastNode = PlayEngine.sow(starterNode);
        // then:
        BoardResponse actualBoardResponse = board.getBoardResponse();
        assertThat(actualBoardResponse.getStones()).isEqualTo(lastStateStones);
        assertThat(actualLastNode.getPit().getId()).isEqualTo(expectedLastNodeId);
        assertThat(actualLastNode.getPit().getOwner()).isEqualTo(player);
    }

    @Test
    @Order(2)
    void sow_happy_path_two_consecutive_play() {
        // given:
        Player player = Player.PLAYER_2;
        int pitId = 2;
        Node starterNode = board.getNode(player, pitId);
        List<Integer> lastStateStones = List.of(1, 7, 7, 7, 7, 7, 1, 6, 0, 7, 7, 7, 7, 1);
        int expectedLastNodeId = 1;
        // when:
        Node actualLastNode = PlayEngine.sow(starterNode);
        // then:
        BoardResponse actualBoardResponse = board.getBoardResponse();
        assertThat(actualBoardResponse.getStones()).isEqualTo(lastStateStones);
        assertThat(actualLastNode.getPit().getId()).isEqualTo(expectedLastNodeId);
        assertThat(actualLastNode.getPit().getOwner()).isEqualTo(player.other());
    }

    @Test
    @Order(3)
    void sow_happy_path_three_consecutive_play() {
        // given:
        Player player = Player.PLAYER_1;
        int pitId = 3;
        Node starterNode = board.getNode(player, pitId);
        List<Integer> lastStateStones = List.of(1, 7, 0, 8, 8, 8, 2, 7, 1, 8, 7, 7, 7, 1);
        int expectedLastNodeId = 3;
        // when:
        Node actualLastNode = PlayEngine.sow(starterNode);
        // then:
        BoardResponse actualBoardResponse = board.getBoardResponse();
        assertThat(actualBoardResponse.getStones()).isEqualTo(lastStateStones);
        assertThat(actualLastNode.getPit().getId()).isEqualTo(expectedLastNodeId);
        assertThat(actualLastNode.getPit().getOwner()).isEqualTo(player.other());
    }
}