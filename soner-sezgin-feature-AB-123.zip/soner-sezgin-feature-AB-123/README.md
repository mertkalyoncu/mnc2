# Mancala Game with Spring Boot

This is a mancala game that has a basic UI and full backend code. Technologies:

* Java 11
* Spring Boot
* Spring MVC
* JQuery
* HTML, CSS, Bootstrap
* Thymeleaf
* JUnit 5
* H2
* Swagger 3

## Thought Process

I have never header the game before. I watched a couple of videos over the internet. After that, I read the problem
description. After reading, the first structure that came to my mind was state machines. After a bit of thinking, I
decided not to proceed with it because our board was not finite. (At least we can call it uncountable.)
\
\
After that, I decided to represent the board exactly as it is in my code. If the players need to sow their stones always
to the right, then a circular linked list would be a great fit.
\
\
Each element of the list would represent the pits that have the attributes like stoneCount, owner, and type (big or
small pit). Each node will have an ID, so we'll have a chance to retrieve only an id value from UI to realize which pit
was selected.
\
\
After retrieving the request, we would apply the rules and calculate the state. Later on, we would send the response
consisting of stone counts in each pit, the information indicating whose turn it is, and the winner. (if there is one.)
Therefore, the UI would handle just the UI, not the logic.

![Alt text](src/main/resources/static/img/design.png?raw=true "Solution Design")

## Build & Run

This is a maven project. So just use maven lifecycle. (*mvn clean compile* to compile)
Since this is a spring boot application, just run MancalaApplication which is annotated with SpringBootApplication.
\
\
The application will run on 8080 port. So to open the home page go to the URL: *http://localhost:8080*
\
\
You will see a button written *Click to Play* on it. Please click it, this will redirect you to the inside the game, and
you will see the game board. Now you're ready to play, just enjoy!

## Testing Endpoints

Swagger was implemented to test the endpoints easily. You will see the endpoint details on Swagger UI. To open the
Swagger UI, please go to: *http://localhost:8080/swagger-ui/*

## Logging

slf4j library was used for logging.

## Session Management

The session is stored both on Spring, and H2 database. Since H2 is in-memory storage inside the application, after
restarting, the session is removed. So it's not fully functional. It can be made functional by using technologies like
Redis or MySQL.

## Unit Tests

Unit tests results:\
Class: %81\
Method: %85\
Line: %84


